from Base_Stein.SVGD_functions import *
from Base_Stein.SVGD_classes import *

#Now we can do, for example
#import Base_Stein as B_S
#B_S.SVGD_functions

#or for example:
#from Base_Stein.SVGD_functions import *
