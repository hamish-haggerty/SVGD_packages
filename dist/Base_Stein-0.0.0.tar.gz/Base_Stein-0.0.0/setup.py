from setuptools import setup, find_packages

setup(
name='Base_Stein',
packages=find_packages(where='src'),
package_dir={'': 'src'},
url='https://github.com/hamish-haggerty/AI-hacking/tree/master/SVGD/SVGD_packages' #comment this out /delete if it doesn't work...
)
